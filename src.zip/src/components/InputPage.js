import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const InputPage = ({ fetchRecommendations }) => {
    const [userDetails, setUserDetails] = useState({
        weight: '',
        height: '',
        age: '',
        gender: '',
        activity_level: '',
    });

    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUserDetails({ ...userDetails, [name]: value });
    };

    const handleSubmit = () => {
        fetchRecommendations(userDetails);
        navigate('/recommendations');
    };

    return (
        <div>
            <h1>Enter Your Details</h1>
            <input name="weight" placeholder="Weight" onChange={handleChange} />
            <input name="height" placeholder="Height" onChange={handleChange} />
            <input name="age" placeholder="Age" onChange={handleChange} />
            <input name="gender" placeholder="Gender" onChange={handleChange} />
            <input name="activity_level" placeholder="Activity Level" onChange={handleChange} />
            <button onClick={handleSubmit}>Submit</button>
        </div>
    );
};

export default InputPage;
