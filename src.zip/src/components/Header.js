// src/components/Header.js
import React from "react";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <header>
      <nav>
        <ul>
          {/* Link to the InputPage (Home) */}
          <li>
            <Link to="/">Input Details</Link>
          </li>

          {/* Link to the exercise recommendations page */}
          <li>
            <Link to="/recommendations">Recommendations</Link>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
