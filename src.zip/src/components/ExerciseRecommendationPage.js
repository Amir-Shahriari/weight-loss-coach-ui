// src/components/ExerciseRecommendationPage.js
import React from "react";
import { Link } from "react-router-dom";

const ExerciseRecommendationPage = ({ results, dailyExercisePlan }) => {
  // If no results are available, show fallback
  if (!results) {
    return <p>No results available. Please go back and enter your details.</p>;
  }

  const { recommended_daily_calorie_intake } = results;

  // Convert the daily calorie intake safely
  const dailyCalorieDisplay =
    typeof recommended_daily_calorie_intake === "number"
      ? recommended_daily_calorie_intake.toFixed(2)
      : "N/A";

  return (
    <div>
      <h1>Your Results</h1>
      <p>
        <strong>Recommended Daily Calorie Intake:</strong>{" "}
        {dailyCalorieDisplay} kcal
      </p>

      <h2>Exercise Options (Each Burns 500 kcal/day)</h2>
      {Array.isArray(dailyExercisePlan) && dailyExercisePlan.length > 0 ? (
        <ul>
          {dailyExercisePlan.map((exercise, index) => {
            const activityName = exercise.activity || "Unnamed Activity";
            const calsPerHour =
              typeof exercise.calories_burned_per_hour === "number"
                ? exercise.calories_burned_per_hour.toFixed(2)
                : "N/A";
            const dailyHours =
              typeof exercise.daily_duration_hours === "number"
                ? exercise.daily_duration_hours.toFixed(2)
                : "N/A";
            const dailyMinutes =
              typeof exercise.daily_duration_minutes === "number"
                ? exercise.daily_duration_minutes.toFixed(1)
                : "N/A";
            const insights = exercise.insights || "No insights available.";
            const dailyBurnAlloc = exercise.daily_burn_allocation || 500;

            // Link to a dedicated details page for this exercise
            // We'll pass the 'index' in the URL param
            return (
              <li key={index}>
                <h3>{activityName}</h3>
                <p><strong>Calories Burned Per Hour:</strong> {calsPerHour}</p>
                <p><strong>Burn Per Day:</strong> {dailyBurnAlloc} kcal</p>
                <p><strong>Daily Duration (Hours):</strong> {dailyHours}</p>
                <p><strong>Daily Duration (Minutes):</strong> {dailyMinutes}</p>
                <Link to={`/exercise/${index}`}>View Details</Link>
              </li>
            );
          })}
        </ul>
      ) : (
        <p>No exercises were suggested for this plan.</p>
      )}
    </div>
  );
};

export default ExerciseRecommendationPage;
