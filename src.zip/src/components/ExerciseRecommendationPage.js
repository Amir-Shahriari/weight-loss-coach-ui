import React from "react";
import "./ExerciseRecommendationPage.css";

const ExerciseRecommendationPage = ({ recommendations }) => {
  return (
    <div className="exercise-recommendation-page" style={{
      padding: "2rem",
      background: "linear-gradient(90deg, #4CAF50, #81C784)",
      minHeight: "100vh",
      color: "white",
      fontFamily: "Arial, sans-serif"
    }}>
      <h1 className="title" style={{
        fontSize: "2rem",
        fontWeight: "bold",
        textAlign: "center",
        marginBottom: "2rem"
      }}>Exercise Recommendations</h1>
      {recommendations && recommendations.length > 0 ? (
        <ul className="recommendation-list" style={{
          listStyleType: "none",
          padding: "0",
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
          gap: "1.5rem"
        }}>
          {recommendations.map((recommendation, index) => (
            <li key={index} className="recommendation-item" style={{
              background: "white",
              borderRadius: "12px",
              boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
              padding: "1.5rem",
              color: "#555",
              textAlign: "center"
            }}>
              <p style={{ fontWeight: "bold", marginBottom: "0.5rem" }}>Activity: {recommendation.activity}</p>
              <p>Duration: {recommendation.daily_duration_minutes} minutes</p>
              <p>Insights: {recommendation.insights}</p>
            </li>
          ))}
        </ul>
      ) : (
        <div className="default-message styled-message" style={{
          background: "rgba(255, 255, 255, 0.9)",
          borderRadius: "12px",
          padding: "1.5rem",
          color: "#4CAF50",
          fontWeight: "bold",
          textAlign: "center",
          boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)"
        }}>
          No recommendations available. Please provide your input to receive suggestions.
        </div>
      )}
    </div>
  );
};

export default ExerciseRecommendationPage;
