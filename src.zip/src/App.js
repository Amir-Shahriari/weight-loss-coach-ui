// src/App.js
import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import axios from "axios";
import Header from "./components/Header";
import InputPage from "./components/InputPage";
import ExerciseRecommendationPage from "./components/ExerciseRecommendationPage";
import ExerciseDetailsPage from "./components/ExerciseDetailsPage";

const App = () => {
  const [results, setResults] = useState(null);

  // We'll store the "daily_exercise_plan" array separately for easy access
  const [dailyExercisePlan, setDailyExercisePlan] = useState([]);

  const handleSubmit = async (data) => {
    try {
      const response = await axios.post(
        "http://127.0.0.1:8000/calculate_and_recommend_daily/",
        data
      );
      // Store the entire response in 'results'
      setResults(response.data);

      // Also store the array of exercises
      if (response.data && response.data.daily_exercise_plan) {
        setDailyExercisePlan(response.data.daily_exercise_plan);
      }
    } catch (error) {
      console.error("Error fetching results:", error);
    }
  };

  return (
    <Router>
      <Header />
      <Routes>
        {/* 1. The page to collect user input */}
        <Route
          path="/"
          element={<InputPage onSubmit={handleSubmit} />}
        />

        {/* 2. The recommendation page (list of exercises) */}
        <Route
          path="/recommendations"
          element={
            <ExerciseRecommendationPage
              results={results}
              dailyExercisePlan={dailyExercisePlan}
            />
          }
        />

        {/* 3. Details page for a single exercise */}
        <Route
          path="/exercise/:index"
          element={<ExerciseDetailsPage dailyExercisePlan={dailyExercisePlan} />}
        />
      </Routes>
    </Router>
  );
};

export default App;
