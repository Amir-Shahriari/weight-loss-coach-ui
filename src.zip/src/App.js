import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import HomePage from './components/HomePage';
import InputPage from './components/InputPage';
import ExerciseRecommendationPage from './components/ExerciseRecommendationPage';

const App = () => {
    return (
        <div>
            {/* Header component remains visible across all routes */}
            <Header />
            <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/input" element={<InputPage />} />
                <Route path="/recommendations" element={<ExerciseRecommendationPage />} />
            </Routes>
        </div>
    );
};

export default App;
